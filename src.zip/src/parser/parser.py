class Parser:
    """ Parser.
    """
    
    def parse(self, cmd):
        """ Pass the command.
        """
		return cmd.split("\\s");