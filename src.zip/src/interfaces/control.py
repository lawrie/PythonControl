class Control:
    """ Interface for call plugins.
    """
    
    def setProvider(self, provider):
        """ Set the provider.
        """
        pass